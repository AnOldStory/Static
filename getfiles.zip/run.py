import selenium
import re
from selenium import webdriver
from selenium.webdriver import ActionChains

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
import time
import argparse

def download_file(url) :
    driver = webdriver.Chrome(executable_path='chromedriver')
    driver.get(url  = url)
        
    result = None
    while result is None :
        try:
            # time.sleep(30)
            driver.execute_script('''document.querySelector("#iframe_rightMenu").contentWindow.document.body.querySelector("#iframe_centerMenu1").contentWindow.document.body.querySelector("#csvradio").checked=true;
        document.querySelector("#iframe_rightMenu").contentWindow.document.body.querySelector("#iframe_centerMenu1").contentWindow.fn_downGridSubmit();''')
            result = True
            print("end")
        except Exception as e:
            pass
    # driver.quit()

parser = argparse.ArgumentParser()

parser.add_argument('--url', dest = "url")
arg = parser.parse_args()

driver = webdriver.Chrome(executable_path='chromedriver')
driver.get(url  = arg.url)
    
result = None
while result is None :
    try:
        # time.sleep(30)
        driver.execute_script('''document.querySelector("#iframe_rightMenu").contentWindow.document.body.querySelector("#iframe_centerMenu1").contentWindow.document.body.querySelector("#csvradio").checked=true;
    document.querySelector("#iframe_rightMenu").contentWindow.document.body.querySelector("#iframe_centerMenu1").contentWindow.fn_downGridSubmit();''')
        result = True
        print("end")
    except Exception as e:
        pass
# TODO: Multi-Processing