#!/bin/bash

MULTI=12

POSITIONAL_ARGS=()

# arg parser ##
function parseArg () {
  while [[ $# -gt 0 ]];
  do
    case $1 in
      -m|--multi)
        # core
        MULTI=$2
        shift # past argument
        shift # past value
        ;;
      -h|--help)
        # help
        echo "Usage: run.sh [options]"
        echo "Options:"
        echo "  -m, --multi <number>  Set the Multi Processing"
        echo "  -h, --help           Show this help"
        echo "script by anoldstory"
        exit 0
        ;;
      -*|--*)
        echo "Unknown option $1"
        exit 1
        ;;
      *)
        POSITIONAL_ARGS+=("$1") # save positional argument
        shift # past argument
        ;;
    esac
  done
}

function runTest(){
  echo ">>> start" $1
  python3 run.py --url $1
  echo "end <<<" $1
}

function runTestParallel(){
  count=0

  for link in $(cat input.txt); do
      runTest $link &
      count=$((count+1))
      if (( count++ > MULTI )); then
        wait -n
      fi
  done
}


function main(){
  parseArg $@

  runTestParallel
}

main $@